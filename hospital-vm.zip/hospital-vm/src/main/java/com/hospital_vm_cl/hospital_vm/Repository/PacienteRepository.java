package com.hospital_vm_cl.hospital_vm.Repository;

import com.hospital_vm_cl.hospital_vm.Model.Paciente;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PacienteRepository extends JpaRepository<Paciente, Long> {

    List<Paciente> findByApellidos(String apellidos);
}
