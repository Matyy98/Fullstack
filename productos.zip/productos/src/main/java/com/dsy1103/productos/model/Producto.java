package com.dsy1103.productos.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Producto {

    //Identeificador unico del producto
    private Integer id;

    //nombre del producto
    //Regla : no puede estar vacio ni contener solo espacio
    @NotBlank(message = "El nombre no puede estar vacio")
    private String nombre;


    //precio del producto
    //Regla : no puede ser nulo y debe ser mayor a 0
    @NotNull(message = "El precio es obligatorio")
    @Positive(message = "El precio debe ser un numero positivo")
    private Double precio;


    //Stock del producto
    //Regla : no puede ser nulo y debe ser mayor o igual a 0
    @NotNull(message = "El stock es obligatorio")
    @PositiveOrZero(message = "el stock debe ser mayor o igual a 0")
    private Integer stock;
}
