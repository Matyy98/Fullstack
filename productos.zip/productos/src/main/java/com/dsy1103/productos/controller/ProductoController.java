package com.dsy1103.productos.controller;

import com.dsy1103.productos.model.Producto;
import com.dsy1103.productos.service.ProductoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.naming.Binding;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/productos")
public class ProductoController {

    @Autowired
    private ProductoService productoService;
    //Endpoint para listar TODOS los productos
    @GetMapping
    public ResponseEntity<?> listarProductos(){
        try {
            //obtener todos los productos desde el servicio
            List<Producto> productos = productoService.listar();
            //retornar la lista y estado ok(200)
            return ResponseEntity.ok(productos);
        } catch (Exception e) {
            //Definir mapa para devolver mensaje de error
            Map<String, String> respuesta = new HashMap<>();
            respuesta.put("Error","Opps! Ocurrio un problema al listar los productos");
            //retornar un codigo 500
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(respuesta);
        }
    }
    //EndPoint para guardar un producto
    @PostMapping
    public ResponseEntity<?> guardarProducto(@Valid @RequestBody
                                                 Producto producto, BindingResult result){
        try {
            //Verificar si hay errores de validacion
            if(result.hasErrors()){
                //Definir el mapa para almacenar los errores por atributo o campo
                Map<String, String> errores = new HashMap<>();
                //Recorro los errores encontrados y los guardo en el mapa
                result.getFieldErrors().forEach(error -> errores.put(error.getField(), error.getDefaultMessage()));
                //retorno 400 BAD REQUEST
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errores);
            }
            //guardo el producto
            Producto newProducto = productoService.guardar(producto);
            //retorno 201 CREATED
            return ResponseEntity.status(HttpStatus.CREATED).body(newProducto);
        } catch (Exception e) {
            //Definir mapa para devolver mensaje de error
            Map<String, String> respuesta = new HashMap<>();
            respuesta.put("Error","Opps! Ocurrio un problema al crear el producto");
            //retornar un codigo 500
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(respuesta);
        }
    }
}
