package com.dsy1103.productos.service;

import com.dsy1103.productos.model.Producto;
import com.dsy1103.productos.repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductoService {
    //Inyecta el repository
    @Autowired
    private ProductoRepository productoRepository;
    //metodo para listar todos los productos
    public List<Producto> listar(){return productoRepository.findAll();}
    //metodo para buscar un producto por su id
    public Producto buscarPorId(Integer id){return productoRepository.findById(id);}
    //metodo para guardar un nuevo producto
    public Producto guardar(Producto producto){return productoRepository.save(producto);}
}
