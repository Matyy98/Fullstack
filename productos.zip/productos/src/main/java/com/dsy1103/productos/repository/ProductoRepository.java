package com.dsy1103.productos.repository;

import com.dsy1103.productos.model.Producto;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class ProductoRepository {

    private List<Producto> listaproductos = new ArrayList<>();
    //Variable para simular el autrincrementro del id
    private Integer contadorId = 1;
    //Constructor del repositorio para datos de prueba
    public ProductoRepository(){
        // agregare un par de producto para probar mi microservicio
        listaproductos.add(new Producto(contadorId++, "Teclado", 15000.0, 10));
        listaproductos.add(new Producto(contadorId++, "Mouse", 8000.0, 20));
        listaproductos.add(new Producto(contadorId++, "Monitor", 120000.0, 5));
    }
    //Metodo para retornar todos los producto


    public List<Producto> findAll() {
        return listaproductos;
    }
    //Metodo para retornar un producto por su id
    public Producto findById(Integer id){
        return listaproductos.stream().filter
                (producto -> producto.getId().equals(id)).findFirst().orElse(null);
    }
    //Metodo para guarda un nuevo producto
    public Producto save(Producto producto){
        //Le asigno id automatico
        producto.setId(contadorId++);
        //agrego el producto a la lista
        listaproductos.add(producto);
        //retorno producto creado
        return producto;
    }
    //Metodo para actualizar un producto existente
    public Producto update(Integer id, Producto productoUpdate){
        //Recorrer la lista
        for (Producto producto : listaproductos){
            //buscar por id
            if(producto.getId().equals(id)){
                //actualizo los atributos
                producto.setNombre(productoUpdate.getNombre());
                producto.setPrecio(productoUpdate.getPrecio());
                producto.setStock(productoUpdate.getStock());
                //rompo el ciclo y retorno el producto
                return producto;
            }
        }
        //si sali del for es porque NO encontre el producto con ese id y retorno NULL
        return null;
    }

    //Metodo para eliminar un producto por su id
    public boolean delete(Integer id){
        for (int i = 0; i < listaproductos.size(); i++) {
            //buscar por el id
            if(listaproductos.get(i).getId().equals(id)){
                //lo elimino de la lista
                listaproductos.remove(i);
                //rompo la ejecucion y retorno true por exito
                return true;
            }
        }
        return false;
    }
}
