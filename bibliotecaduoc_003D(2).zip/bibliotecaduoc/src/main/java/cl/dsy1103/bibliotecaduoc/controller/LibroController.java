package cl.dsy1103.bibliotecaduoc.controller;

import cl.dsy1103.bibliotecaduoc.dto.LibroRequestDTO;
import cl.dsy1103.bibliotecaduoc.dto.LibroResponseDTO;
import cl.dsy1103.bibliotecaduoc.model.Categoria;
import cl.dsy1103.bibliotecaduoc.model.Libro;
import cl.dsy1103.bibliotecaduoc.service.LibroService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * * ═══════════════════════════════════════════════════
 * * CLASE: LibroController.java
 * * CAMBIOS RESPECTO A CLASE 2:
 * *   1. No importa la entidad Libro en ningún lugar.
 * *   2. POST y PUT reciben @Valid LibroRequestDTO.
 * *      Si la validación falla → GlobalExceptionHandler
 * *      devuelve 400 con mapa { campo: mensaje }.
 * *   3. Todos los métodos devuelven LibroResponseDTO.
 * * ═══════════════════════════════════════════════════*/
@RestController
@RequestMapping("/api/libros")
@RequiredArgsConstructor
public class LibroController {

    private final LibroService libroService;

    // GET /api/libros → 200 OK con lista
    @GetMapping
    public ResponseEntity<List<LibroResponseDTO>> obtenerTodos(){
        return ResponseEntity.ok(libroService.obtenerTodos());
    }

    // GET /api/libros/{id} → 200 OK o 404 Not Found
    @GetMapping("{id}")
    public ResponseEntity<LibroResponseDTO> obtenerPorId(@PathVariable Long id) {
        return libroService.obtenerPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // POST /api/libros → 201 Created
    // @Valid dispara las validaciones del DTO.
    // Si un campo falla → GlobalExceptionHandler → 400
    //   { "titulo": "El título no puede estar vacío" }
    // Si el categoriaId no existe → GlobalExceptionHandler → 400
    //   { "error": "Categoría no encontrada con id: 99" }
    @PostMapping
    public ResponseEntity<LibroResponseDTO> crear(
            @Valid @RequestBody LibroRequestDTO dto){
        return ResponseEntity.status(201).body(libroService.guardar(dto));
    }

    // PUT /api/libros/{id} → 200 OK o 404 Not Found
    // @Valid también aplica aquí: mismas validaciones que en POST.
    @PutMapping("{id}")
    public ResponseEntity<LibroResponseDTO>  actualizar(
            @PathVariable Long id,
            @Valid @RequestBody LibroRequestDTO dto){
        return libroService.actualizar(id, dto)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // DELETE /api/libros/{id} → 204 No Content o 404 Not Found
    @DeleteMapping("{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id){
        if (libroService.obtenerPorId(id).isEmpty()){
            return ResponseEntity.notFound().build();
        }
        libroService.eliminar(id);
        return ResponseEntity.noContent().build(); //204
    }

    // ── BÚSQUEDAS ────────────────────────────────────
    @GetMapping("/buscar")
    public ResponseEntity<List<LibroResponseDTO>> buscarPorTitulo(
            @RequestParam String titulo) {
        return ResponseEntity.ok(libroService.buscarPorTitulo(titulo));
    }

    @GetMapping("/categoria/{id}")
    public ResponseEntity<List<LibroResponseDTO>> buscarPorCategoria(
            @PathVariable Long id) {
        return ResponseEntity.ok(libroService.buscarPorCategoria(id));
    }

    @GetMapping("/presupuesto")
    public ResponseEntity<List<LibroResponseDTO>> bajoPresupuesto(
            @RequestParam Double max) {
        return ResponseEntity.ok(libroService.buscarBajoPresupuesto(max));
    }
}
