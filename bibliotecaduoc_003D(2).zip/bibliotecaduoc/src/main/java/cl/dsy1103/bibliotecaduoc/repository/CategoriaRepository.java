package cl.dsy1103.bibliotecaduoc.repository;

import cl.dsy1103.bibliotecaduoc.model.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;
/**
 * ═══════════════════════════════════════════════════
 * CLASE: CategoriaRepository.java
 * Acceso a datos. JpaRepository provee CRUD completo
 * sin escribir SQL ni código de implementación.
 * ═══════════════════════════════════════════════════

 * JpaRepository<Entidad, TipoPK> hereda:
 *   save()        → INSERT o UPDATE automático
 *   findById()    → SELECT WHERE id = ?
 *   findAll()     → SELECT * FROM categorias
 *   deleteById()  → DELETE WHERE id = ?
 *   count()       → SELECT COUNT(*)
 *   existsById()  → comprueba si existe un id*/
public interface CategoriaRepository extends JpaRepository<Categoria,Long> {
}
