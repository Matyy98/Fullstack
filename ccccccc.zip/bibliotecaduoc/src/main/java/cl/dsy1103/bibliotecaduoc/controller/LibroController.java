package cl.dsy1103.bibliotecaduoc.controller;

import cl.dsy1103.bibliotecaduoc.model.Libro;
import cl.dsy1103.bibliotecaduoc.service.LibroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1/libros")
public class LibroController {
    @Autowired
    private LibroService libroService;

    @GetMapping
    public List<Libro> listarLibros(){
        return libroService.getLibros();
    }

    @GetMapping("{id}")
    public Libro buscarLibro(@PathVariable int id){
        return libroService.getLibroId(id);
    }

    @GetMapping("/totalV1")
    public int totalLibros(){
        return libroService.totalLibrosV1();
    }
    @GetMapping("/totalV2")
    public int totalLibrosV2(){ return libroService.totalLibrosV2(); }
    @GetMapping("/isbn/{isbn}")
    public Libro buscarIsbn(@PathVariable String isbn){return libroService.buscarIsbn(isbn); }
    @GetMapping("/buscar/{fechaPublicacion}")
    public Libro buscarFecha(@PathVariable int fechaPublicacion){return libroService.buscarFecha(fechaPublicacion);}
    @PostMapping
    public Libro agregarLibro(@RequestBody Libro libro){
        return libroService.saveLibro(libro);
    }

    @PutMapping("{id}")
    public Libro actualizarLibro(@PathVariable int id, @RequestBody Libro libro){
        //queda pendiente actualizar por ID
        return libroService.updateLibro(libro);
    }

    @DeleteMapping("{id}")
    public String eliminarLibro(@PathVariable int id){
        return libroService.deleteLibro(id);
    }

}
