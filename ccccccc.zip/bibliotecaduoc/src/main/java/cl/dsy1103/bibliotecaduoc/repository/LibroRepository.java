package cl.dsy1103.bibliotecaduoc.repository;

import cl.dsy1103.bibliotecaduoc.model.Libro;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class LibroRepository {
    //una lista privada que almacenará los libros de forma TEMPORAL
    private List<Libro> listaLibros = new ArrayList<>();

    /*
       Método que retorne todos los libros
       almacenados en la lista
    * */
    public List<Libro> obtenerLibros(){
        return listaLibros;
    }

    //Crearé un libro forzadamente
    public LibroRepository(){
        listaLibros.add(new Libro(1, "9789569646638", "Fuego y Sangre", "Penguin Random House Grupo Editorial", 2018, "George R. R. Martin"));
        listaLibros.add(new Libro(2, "9789563494150", "Quique Hache: El Mall Embrujado y Otras Historias", "Sm Ediciones", 2014, "Sergio Gomez"));
        listaLibros.add(new Libro(3, "9781484256251", "Spring Boot Persistence Best Practices", "Apress", 2020, "Anghel Leonard"));
        listaLibros.add(new Libro(4, "9789566075752", "Harry Potter y la piedra filosofal", "Salamandra", 2024, "J. K. Rowling"));
        listaLibros.add(new Libro(5, "9780439139601", "Harry Potter y el prisionero de Azkaban", "Scholastic", 1999, "J. K. Rowling"));
        listaLibros.add(new Libro(6, "9780439136365", "Harry Potter y el cáliz de fuego", "Scholastic", 2000, "J. K. Rowling"));
        listaLibros.add(new Libro(7, "9780321127426", "Effective Java", "Addison-Wesley", 2008, "Joshua Bloch"));
        listaLibros.add(new Libro(8, "9780134685991", "Clean Architecture", "Prentice Hall", 2017, "Robert C. Martin"));
        listaLibros.add(new Libro(9, "9780201633610", "Design Patterns", "Addison- Wesley", 1994, "Erich Gamma, Richard Helm, Ralph Johnson, John Vlissides"));
        listaLibros.add(new Libro(10, "9780132350884", "Clean Code", "Prentice Hall", 2008, "Robert C. Martin"));
    }

    //buscar libro por su Id
    public Libro buscarPorId(int id){
        for (Libro libro: listaLibros){
            if(libro.getId()== id){
                return libro;
            }
        }
        return null;
    }

    public Libro buscarPorAnnio(int fechaPublicacion){
        for (Libro libro: listaLibros){
            if(libro.getFechaPublicacion()== fechaPublicacion){
                return libro;
            }
        }
        return null;
    }

    //buscar libro por isbn
    public Libro buscarPorIsbn(String isbn){
        for (Libro libro: listaLibros){
            if(libro.getIsbn().equals(isbn)){
                return libro;
            }
        }
        return null;
    }

    //método para guardar libro
    public Libro guardar(Libro lib){
        listaLibros.add(lib);
        return lib;
    }

    //método pra actualizar
    public Libro actualizar(Libro lib){
        int id = 0;
        int idPosicion = -1;

        for (int i = 0; i < listaLibros.size(); i++) {
            if (listaLibros.get(i).getId() == lib.getId()){
                id = lib.getId();
                idPosicion = i;
            }
        }
        Libro libro1 = new Libro();
        if(idPosicion != -1){
            libro1.setId(id);
            libro1.setAutor(lib.getAutor());
            libro1.setIsbn(lib.getIsbn());
            libro1.setTitulo(lib.getTitulo());
            libro1.setEditorial(lib.getEditorial());
            libro1.setFechaPublicacion(lib.getFechaPublicacion());

            listaLibros.set(idPosicion,libro1);
        }
        return libro1;
    }

    public void eliminar(int id){
        //alternativa 1: usar el método de busqueda y una vez encontrado el objeto uso 'remove'
        Libro libro = buscarPorId(id);
        if (libro != null){
            listaLibros.remove(libro);
        }

        //alternativa 2: eliminar por posición. Recooro la colección, obtengo la posición y la elimino
        int idPosicion = 0;
        for (int i = 0; i < listaLibros.size(); i++) {
            if (listaLibros.get(i).getId() ==id){
                idPosicion = i;
                break;
            }
        }
        if(idPosicion > 0){
           listaLibros.remove(idPosicion);
        }

        //alternativa 3: utilizar función Lambda o flecha
        listaLibros.removeIf(x-> x.getId() == id);
    }

    public int totalLibrosV1(){
        return listaLibros.size();
    }
}
