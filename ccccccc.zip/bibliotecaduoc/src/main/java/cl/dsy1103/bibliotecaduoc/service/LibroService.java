package cl.dsy1103.bibliotecaduoc.service;

import cl.dsy1103.bibliotecaduoc.model.Libro;
import cl.dsy1103.bibliotecaduoc.repository.LibroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LibroService {

    @Autowired
    private LibroRepository libroRepository;

    public List<Libro> getLibros(){
        return libroRepository.obtenerLibros();
    }

    public Libro saveLibro(Libro libro){
        return libroRepository.guardar(libro);
    }

    public Libro getLibroId(int id){
        return libroRepository.buscarPorId(id);
    }

    public Libro updateLibro(Libro libro){
        return libroRepository.actualizar(libro);
    }

    public String deleteLibro(int id){
        libroRepository.eliminar(id);
        return "Libro eliminado OK";
    }

    public int totalLibrosV1(){
        return libroRepository.totalLibrosV1();
    }
    public int totalLibrosV2(){return libroRepository.obtenerLibros().size();

    }
    public Libro buscarIsbn(String isbn){return libroRepository.buscarPorIsbn(isbn); }

    public Libro buscarFecha(int fechaPublicacion){return libroRepository.buscarPorAnnio(fechaPublicacion);}

}
