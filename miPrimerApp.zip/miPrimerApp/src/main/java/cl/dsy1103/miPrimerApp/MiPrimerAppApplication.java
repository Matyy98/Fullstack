package cl.dsy1103.miPrimerApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiPrimerAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiPrimerAppApplication.class, args);
	}

}
