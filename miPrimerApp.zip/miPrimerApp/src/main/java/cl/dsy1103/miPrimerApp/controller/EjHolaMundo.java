package cl.dsy1103.miPrimerApp.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/miapp")
public class EjHolaMundo {

    @GetMapping("/s1")
    public String saludo(){
        return "Hola Mundo con SPRING";
    }
    @GetMapping("/s2")
    public String saludo2(){
        return "Buenos días, buenas tardes!!";
    }
}
