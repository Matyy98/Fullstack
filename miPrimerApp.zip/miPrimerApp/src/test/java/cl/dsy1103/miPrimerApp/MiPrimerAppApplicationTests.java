package cl.dsy1103.miPrimerApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiPrimerAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
