package cl.dsy1103.productos.model;
//Importa anotaciones de validación Jakarta
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;

//Importa anotaciones de Lombok
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data //genera automáticamente get&set, tostring, equals, hashcode
@NoArgsConstructor//genera constructor vacío
@AllArgsConstructor//genera constructor con parámetros


public class Producto {

    //Identificador único del producto
    private Integer id;

    //nombre del producto
    //Regla:  no puede estar vacío ni contener solo espacios
    @NotBlank(message = "El nombre no puede estar vacío")
    private String nombre;

    //precio del producto
    //Regla:  no puede nulo y debe ser mayor a cero
    @NotNull(message = "El precio es obligatorio")
    @Positive(message = "El precio debe ser mayor a cero(0)")
    private Double precio;

    //stock del producto
    //Regla:  no puede nulo y debe ser mayor o igual a cero
    @NotNull(message = "El stock es obligatorio")
    @PositiveOrZero(message = "El stock debe ser mayor o igual a cero(0)")
    private Integer stock;


}
