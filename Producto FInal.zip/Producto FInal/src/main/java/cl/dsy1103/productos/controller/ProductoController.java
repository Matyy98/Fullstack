package cl.dsy1103.productos.controller;

import cl.dsy1103.productos.model.Producto;
import cl.dsy1103.productos.service.ProductoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

//Marcar esta clase como controlador REST
@RestController
//Defino la rura base para acceder a mi microservicio
@RequestMapping("/api/productos")
public class ProductoController {

    // Inyecta el servicio
    @Autowired
    private ProductoService productoService;

    //EndPoint para listar TODOS los productos
    @GetMapping
    public ResponseEntity<?> listarProductos(){
        try{
           //Obtener todos los productos desde el servicio
            List<Producto> productos = productoService.listar();
            //retornar la lista y estado ok(200)
            return ResponseEntity.ok(productos);
        } catch (Exception e) {
            //Definir Mapa para devolver mensaje de error
            Map<String , String > respuesta = new HashMap<>();
            respuesta.put("error","Opps! Ocurrió un problema al listar los productos");
            //retornar un código 500
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(respuesta);
        }
    }

    //EndPoint para guardar un producto
    @PostMapping
    public ResponseEntity<?> guardarProducto(@Valid @RequestBody Producto producto,
                                             BindingResult result){
        try{
            //Verificar si hay errores de validación
            if(result.hasErrors()){
                //Definir el mapa para almacenar los errores por atributo o campo
                Map<String,String> errores = new HashMap<>();

                //Recorro los errores encontrados y los guardo en el mapa
                result.getFieldErrors().forEach(error ->
                        errores.put(error.getField(), error.getDefaultMessage()));
                //retorno 400 BAD REQUEST
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errores);
            }
            //guardo el producto
            Producto newProducto = productoService.guardar(producto);
            //Retorno 2001 CREATED
            return ResponseEntity.status(HttpStatus.CREATED).body(newProducto);

        } catch (Exception e) {
            //Definir Mapa para devolver mensaje de error
            Map<String , String > respuesta = new HashMap<>();
            respuesta.put("error","Opps! Ocurrió un problema al crear el producto");
            //retornar un código 500
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(respuesta);
        }
    }

    //EndPoint para actualizar
    @PutMapping("{id}")
    public ResponseEntity<?> actualizarProducto( @PathVariable Integer id,
                                            @Valid @RequestBody Producto producto,
                                             BindingResult result){
        try{
            //Verificar si hay errores de validación
            if(result.hasErrors()){
                //Definir el mapa para almacenar los errores por atributo o campo
                Map<String,String> errores = new HashMap<>();

                //Recorro los errores encontrados y los guardo en el mapa
                result.getFieldErrors().forEach(error ->
                        errores.put(error.getField(), error.getDefaultMessage()));
                //retorno 400 BAD REQUEST
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errores);
            }
            //actualizo el producto
            Producto productoUpdate = productoService.actualizar(id, producto);
            //Si producto NO existe devolver error 400 BAD REQUEST
            if(productoUpdate == null){
                //Definir Mapa para devolver mensaje de error
                Map<String , String > error = new HashMap<>();
                error.put("Error","No se puede actualizar");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
            }

            //Retorno 201 CREATED
            return ResponseEntity.ok(productoUpdate);

        } catch (Exception e) {
            //Definir Mapa para devolver mensaje de error
            Map<String , String > respuesta = new HashMap<>();
            respuesta.put("error","Opps! Ocurrió un problema al crear el producto");
            //retornar un código 500
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(respuesta);
        }
    }

    @DeleteMapping("{id}")
    public ResponseEntity<?> eliminarProducto(@PathVariable Integer id){
        try{
            //eliminar el producto
            boolean eliminado = productoService.eliminar(id);
            if (!eliminado){
                Map<String , String> error = new HashMap<>();
                error.put("Error", "Error no se pudo eliminar");
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);
            }
            //Si llego aca es porque elimine correctamente y armo una salida
            Map<String, String> resp = new HashMap<>();
            resp.put("Mensaje", "Producto eliminado correctamente");

            return ResponseEntity.ok(resp);
        } catch (Exception e) {
            Map<String, String> respuesta = new HashMap<>();
            respuesta.put("Error", "Error");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(respuesta);
        }
    }
}
