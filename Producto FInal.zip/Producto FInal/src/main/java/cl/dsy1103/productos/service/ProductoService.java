package cl.dsy1103.productos.service;
// Importa el modelo Producto
import cl.dsy1103.productos.model.Producto;
// Importa el repositorio
import cl.dsy1103.productos.repository.ProductoRepository;
// Importa anotaciones de Spring
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
// Importa listas
import java.util.List;

// Marca esta clase como servicio
@Service
public class ProductoService {
    // Inyecta el repositorio
    @Autowired
    private ProductoRepository productoRepository;

    // Método para listar todos los productos
    public List<Producto> listar() {return productoRepository.findAll();}

    // Método para buscar un producto por id
    public Producto buscarPorId(Integer id){return productoRepository.findById(id);}

    // Método para guardar un nuevo producto
    public Producto guardar(Producto producto){return productoRepository.save(producto);}

    //Metodo para actualizar un producto existente
    public Producto actualizar(Integer id, Producto producto){return productoRepository.update(id, producto);}

    //Metodo para eliminar por id
    public boolean eliminar(Integer id){return productoRepository.delete(id);}
}
