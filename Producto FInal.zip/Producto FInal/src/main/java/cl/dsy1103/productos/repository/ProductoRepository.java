package cl.dsy1103.productos.repository;


import cl.dsy1103.productos.model.Producto;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

//Marcar la clase como Repository
@Repository
public class ProductoRepository {

    //Lista en memoria que simule la Base de Datos
    private List<Producto> listaProductos = new ArrayList<>();

    //Variable para simular el autoincremento del id
    private Integer contadorId = 1;

    //Constructor del repositorio para datos de prueba
    public ProductoRepository(){
        //agregaré un par de productos para probar mi microservicio
        listaProductos.add(new Producto(contadorId++, "Teclado",15000.0,10));
        listaProductos.add(new Producto(contadorId++, "Mouse",8000.0,20));
        listaProductos.add(new Producto(contadorId++, "Monitor",120000.0,5));
    }

    //Método para retornar TODOS los productos
    public List<Producto> findAll() {
        return listaProductos;
    }

    //Método para retornar un producto por su id
    public Producto findById(Integer id){
       return  listaProductos.stream()
               .filter(producto -> producto.getId().equals(id))
               .findFirst()
               .orElse(null);
    }

    //Método para guardar un nuevo producto
    public Producto save(Producto producto){
        //le asigno id automático
        producto.setId(contadorId++);
        //agrego el producto a la lista
        listaProductos.add(producto);
        //retorno producto creado
        return producto;
    }

    //Método para actualizar un producto existente
    public Producto update(Integer id, Producto productoUpdate){
        //recorrer la lista
        for (Producto producto : listaProductos){
            //buscar por id
            if(producto.getId().equals(id)){
                //actualizo los atributos
                producto.setNombre(productoUpdate.getNombre());
                producto.setPrecio(productoUpdate.getPrecio());
                producto.setStock(productoUpdate.getStock());
                //rompo el ciclo y retorno el producto
                return producto;
            }
        }
        //si salí del for es porque NO encontré el id y retorno null
        return null;
    }

    //Método para eliminar un producto por su Id
    public boolean delete(Integer id){
        //recorrer la lista usando el índice
        for (int i = 0; i < listaProductos.size(); i++) {
            //buscar por el id
            if (listaProductos.get(i).getId().equals(id)){
                //lo elimino de la lista
                listaProductos.remove(i);
                //rompo la ejecución y retorno true por exito
                return true;
            }
        }
        //si salí del for es porque NO encontré el id y retorno false
        return false;
    }
}
