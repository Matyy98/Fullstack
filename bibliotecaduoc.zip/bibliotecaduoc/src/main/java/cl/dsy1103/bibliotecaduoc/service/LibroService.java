package cl.dsy1103.bibliotecaduoc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LibroService {
    @Autowired
    private LibroRepository libroRepository;
/*
    public List<Libro> getLibros(){
        return libroRepository.obtenerLibros();
    }

    public Libro saveLibro(Libro libro){
        return libroRepository.guardar(libro);
    }

    public Libro getLibroId(int id){
        return libroRepository.buscarPorId(id);
    }

    public Libro getLibroIsbn(String isbn){
        return libroRepository.buscarPorIsbn(isbn);
    }

    public Libro updateLibro(Libro libro){
        return libroRepository.actualizar(libro);
    }

    public String deleteLibro(int id){
        libroRepository.eliminar(id);
        return "Libro Eliminado!!";
    }


    public int totalLibrosV1(){
        return libroRepository.obtenerLibros().size();
    }

    public int totalLibrosV2(){
        return libroRepository.totalLibros();
    }

    public int totalPorAnnioV1(int annio){
        return libroRepository.totalPorAnnioV1(annio);
    }

    public int totalPorAnnioV2(int annio){
        return libroRepository.totalPorAnnioV2(annio);
    }

    public List<Libro> ordenarPorAnnioV1(){
        return libroRepository.ordenarPorAnnioV1();
    }

    public List<Libro> ordenarPorAnnioV2(){return libroRepository.ordenarPorAnnioV2(); }

    public Libro getLibroAutor(String autor){
        return libroRepository.buscarPorAutor(autor);
    }

    public Libro getOld(){ return libroRepository.masAntiguo();}
    public Libro getNew(){ return libroRepository.masNuevo();}*/
}
