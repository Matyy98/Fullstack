package cl.dsy1103.bibliotecaduoc.service;

import cl.dsy1103.bibliotecaduoc.dto.LibroRequestDTO;
import cl.dsy1103.bibliotecaduoc.dto.LibroResponseDTO;
import cl.dsy1103.bibliotecaduoc.model.Categoria;
import cl.dsy1103.bibliotecaduoc.model.Libro;
import cl.dsy1103.bibliotecaduoc.repository.CategoriaRepository;
import cl.dsy1103.bibliotecaduoc.repository.LibroRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class LibroService {
    private final LibroRepository libroRepository;

    private final CategoriaRepository categoriaRepository;

    private LibroResponseDTO mapToDTO(Libro libro){
        return new LibroResponseDTO(
                libro.getId(),
                libro.getTitulo(),
                libro.getIsbn(),
                libro.getPrecio(),
                libro.getCategoria().getNombre()
        );
    }

    public List<LibroResponseDTO> obtenerTodos(){
        return libroRepository.findAll()
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public Optional<LibroResponseDTO>  obtenerPorId(Long id){
        return libroRepository.findById(id).map(this::mapToDTO);
    }
    public LibroResponseDTO guardar(LibroRequestDTO dto){
        Categoria categoria = categoriaRepository
                .findById(dto.getCategoriaID())
                .orElseThrow(() -> new RuntimeException("Categoria no encontrada con id"+dto.getCategoriaID()));
        Libro libro = new Libro()

    }


}
