package cl.dsy1103.bibliotecaduoc.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Libros")
public class Libro {

   @Id
   @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Long id;
   @Column(nullable = false,length = 20,unique = true)
   private String isbn;
   @Column(nullable = false,length = 200)
   private String titulo;
   @Column(nullable = false, precision = 10,scale = 2)
   private BigDecimal precio;

   @ManyToOne
   @JoinColumn(name = "categoria id", nullable = false)
   private Categoria categoria;

}
