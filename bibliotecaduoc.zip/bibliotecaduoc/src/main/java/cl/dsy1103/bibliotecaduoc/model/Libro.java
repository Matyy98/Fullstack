package cl.dsy1103.bibliotecaduoc.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data //genera get&set(), tostring(), equals, hashCode.
@AllArgsConstructor //Genera un constructor con todos los campos
@NoArgsConstructor //Genera un constructor vacio
public class Libro {

    private int id;
    private String isbn;
    private String titulo;
    private String editorial;
    private int fechaPublicacion;
    private String autor;
}
