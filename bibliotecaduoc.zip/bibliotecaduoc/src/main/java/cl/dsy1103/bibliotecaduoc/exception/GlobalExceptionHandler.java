package cl.dsy1103.bibliotecaduoc.exception;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.LinkedHashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler {
    //Error de validacion (@Valid)
    //Se dispara cuando un campo del RequestDTO no cumple
    //Las restricciones (@NotBlank @Positive, etc.
    //Spring lanza MethodargumentNotValidException
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, String>> handleValidationErrors(
            MethodArgumentNotValidException ex){
    Map<String, String> errores = new LinkedHashMap<>();
    ex.getBindingResult().getFieldErrors().forEach(error ->
            errores.put(error.getField(),error.getDefaultMessage()));
    return ResponseEntity.badRequest().body(errores);

    }

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<Map<String,String>> handleRuntimeException(
            RuntimeException ex){
        Map<String, String> error = new LinkedHashMap<>();
        error.put("Error",ex.getMessage());

        return ResponseEntity.badRequest().body(error);
    }
}
