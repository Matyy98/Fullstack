package cl.dsy1103.bibliotecaduoc.service;

import cl.dsy1103.bibliotecaduoc.model.Categoria;
import cl.dsy1103.bibliotecaduoc.repository.CategoriaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class CategoriaService {

    private final CategoriaRepository categoriaRepository;

    public List<Categoria> obtenerTodos(){return categoriaRepository.findAll();}
    public Optional<Categoria> obtenerPorId(Long id){return categoriaRepository.findById(id);}
    public Categoria guardar(Categoria categoria){return categoriaRepository.save(categoria);}
    public void eliminar(Long id){categoriaRepository.deleteById(id);}

}
