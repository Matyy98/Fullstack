package cl.dsy1103.bibliotecaduoc.dto;


import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LibroRequestDTO {
    /*
    No tiene campo "Id": MySQL lo genera.
    El cliente no debe poder enviarlo
     */
    @NotBlank(message = "El titulo no puede estar vacio")
    private String titulo;

    @NotBlank(message = "El ISBN no puede estar vacio")
    private String isbn;

    @NotNull(message = "El precio es obligatorio")
    @PositiveOrZero(message = "El precio debe ser mayor a 0")
    private BigDecimal precio;

    //Solo el id d ela cateogria. El service busca
    //el objeto Cateogira en BD usando este id
    @NotNull(message = "El categoriaID es obligatorio")
    private Long categoriaID;

}
