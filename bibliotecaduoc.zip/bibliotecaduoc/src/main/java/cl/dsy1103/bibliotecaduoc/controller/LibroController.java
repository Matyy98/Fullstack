package cl.dsy1103.bibliotecaduoc.controller;

import cl.dsy1103.bibliotecaduoc.model.Libro;
import cl.dsy1103.bibliotecaduoc.service.LibroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class LibroController {
    @Autowired
    private LibroService libroService;

    @GetMapping
    public List<Libro> listaLirbos(){
        return libroService.getLibros();
    }
    @PostMapping
    public Libro agregarLibro(@RequestBody Libro libro){
        return libroService.saveLibro(libro);
    }
}
