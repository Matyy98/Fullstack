package cl.dsy1103.bibliotecaduoc.controller;

import cl.dsy1103.bibliotecaduoc.model.Libro;
import cl.dsy1103.bibliotecaduoc.service.LibroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/libros")
public class LibroController {
/*
    @Autowired
    private LibroService libroService;

    @GetMapping
    public List<Libro> listarLibros(){
        return libroService.getLibros();
    }

    @GetMapping("{id}")
    public Libro buscarLibroPorId(@PathVariable int id){
        return libroService.getLibroId(id);
    }

    @GetMapping("libroisbn/{isbn}")
    public Libro buscarLibroPorIsbn(@PathVariable String isbn){
        return libroService.getLibroIsbn(isbn);
    }

    @GetMapping("/totalV1")
    public int totalibrosV1(){
        return libroService.totalLibrosV1();
    }

    @GetMapping("/totalV2")
    public int totalibrosV2(){
        return libroService.totalLibrosV2();
    }

    @GetMapping("/totalV3/{annio}")
    public int totalPorAnioV1(@PathVariable int annio){
        return libroService.totalPorAnnioV1(annio);
    }

    @GetMapping("/totalV4/{annio}")
    public int totalPorAnioV2(@PathVariable int annio){
        return libroService.totalPorAnnioV2(annio);
    }

    @GetMapping("/ordenV1")
    public List<Libro> ordenarPorAnnioV1(){
        return libroService.ordenarPorAnnioV1();
    }

    @GetMapping("/ordenV2")
    public List<Libro> ordenarPorAnnioV2(){
        return libroService.ordenarPorAnnioV2();
    }

    @GetMapping("/autor/{autor}")
    public Libro getLibroAutor(@PathVariable String autor){
        return libroService.getLibroAutor(autor);
    }

    @GetMapping("/old")
    public Libro getOld(){
        return libroService.getOld();
    }

    @GetMapping("/new")
    public Libro getNew(){
        return libroService.getNew();
    }

    @PostMapping
    public Libro agregarLibro(@RequestBody Libro libro){
        return libroService.saveLibro(libro);
    }

    @PutMapping("{id}")
    public Libro actualizarLibro(@PathVariable int id, @RequestBody Libro libro){
        //el id se usa después
        return libroService.updateLibro(libro);
    }

    @DeleteMapping("{id}")
    public String eliminarLibro(@PathVariable int id){
        return libroService.deleteLibro(id);
    }

 */
}
