package cl.dsy1103.bibliotecaduoc.repository;

import cl.dsy1103.bibliotecaduoc.model.Libro;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LibroRepository extends JpaRepository<Libro,Long> {
    //Convencion de Nombress
        List<Libro> findByTituloContainingIgnoreCase(String titulo);
}
