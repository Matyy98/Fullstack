package cl.dsy1103.bibliotecaduoc.repository;

import cl.dsy1103.bibliotecaduoc.model.Libro;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class LibroRepository {
    // Una lista privada que almacenara los libros de forma TEMPORAL
    private List<Libro> listalibros = new ArrayList<>();

    //Metodo que retorne todos los libros almacenados en la lista
    public List<Libro> obtenerLibros(){
        return listalibros;
    }

    //Creare un libro forzodamante
    public LibroRepository(){
        listalibros.add(new Libro(100,"842340949x", "El metodo Lean Startup", "Deusto", 2012, "Eric Ries"));
    }
    //Buscar libro por su id
    public Libro buscarPorId(int id){
        for (Libro libro: listalibros){
            if(libro.getId()== id){
                return libro;
            }
        }
        return null;
    }
    //Buscar libro por isbn
    public Libro buscarPorIsbn(String isbn){
        for (Libro libro: listalibros){
            if(libro.getIsbn().equals(isbn)){
                return libro;
            }
        }
        return null;
    }

    //metodo para guardar libro
    public Libro guardar(Libro lib){
        listalibros.add(lib);
        return lib;
    }
    //metodo para actualizar
    public Libro actualizar(Libro lib){
        int id = 0;
        int idPosicion = 0;

        for (int i = 0; i < listalibros.size() ; i++) {
            if (listalibros.get(i).getId() == lib.getId()){
                id = lib.getId();
                idPosicion = i;
            }
        }
        Libro libro1 = new Libro();
        libro1.setId(id);
        libro1.setAutor(lib.getAutor());
        libro1.setIsbn(lib.getIsbn());
        libro1.setTitulo(lib.getTitulo());
        libro1.setEditorial(lib.getEditorial());
        libro1.setFechaPublicacion(lib.getFechaPublicacion());
        listalibros.set(idPosicion,libro1);
        return libro1;
    }
}
