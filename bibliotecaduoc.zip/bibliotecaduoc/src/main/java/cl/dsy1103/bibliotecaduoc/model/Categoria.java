package cl.dsy1103.bibliotecaduoc.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
/*
 *Crear la clase para llevar esta entidad a la base
 *  de datos
 * Las validaciones NO estaran aca
 * Estaran en DTO: Tenerlas aca es codigo muerto
 * Que solo confunde
 */


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "categorias")
public class Categoria {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    //Not null sigue aqui; es una restriccion de bd

    @Column(nullable = false, length = 100)
    private String nombre;

    @Column
    private String descripcion;

}
