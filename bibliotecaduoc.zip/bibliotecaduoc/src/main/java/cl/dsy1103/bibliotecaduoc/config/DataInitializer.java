package cl.dsy1103.bibliotecaduoc.config;

public class DataInitializer {
}
