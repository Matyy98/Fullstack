package cl.dsy1103.bibliotecaduoc.repository;

public interface CategoriaRepository {
}
